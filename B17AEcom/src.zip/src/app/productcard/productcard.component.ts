import { Component, OnInit } from '@angular/core';
import { ProductService } from '../product.service';

@Component({
  selector: 'app-productcard',
  templateUrl: './productcard.component.html',
  styleUrls: ['./productcard.component.scss']
})
export class ProductcardComponent implements OnInit {
  
  productlist: any;
  click:boolean=false;
  selected=false;
  url="http://bookcart.azurewebsites.net/upload/"

  constructor(private listservice:ProductService) { }

  ngOnInit(): void {
    this.listservice.productcard()
    .subscribe((data:any) => {this.productlist=data;
      console.log(this.productlist)
    });
  }





toggleselected(){
  if(this.selected ==false){
    this.selected =true;
  }else{
    this.selected = false;
  }}
}




